Ansible Playbook
================

[Ansible][1] provisioning tool.

Install
-------

```bash
$ virtualenv venv --distribute
$ source venv/bin/activate
$ pip install ansible
```

[1]: http://www.ansibleworks.com/

