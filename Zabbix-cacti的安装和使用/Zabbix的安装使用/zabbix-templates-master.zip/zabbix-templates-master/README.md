zabbix-templates
================

Zabbix templates for various services and applications.

Currently there are:

* iostat
* Nginx
* php-fpm
* MySQL
* JVM

There're READMEs for every templates. 

## TODO

* Low-level discovery for JVM
* ZooKeeper
* Storm
* Hadoop
