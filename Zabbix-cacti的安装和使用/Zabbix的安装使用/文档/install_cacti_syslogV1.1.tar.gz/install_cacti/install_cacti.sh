#!/bin/bash
#function +++++++++++++cacti auto install scripts+++++++++++++++++++
#author itnihao 
#version 1.0 
#date 2012-08-17 
#mail itnihao@qq.com 
#转载请注明http://itnihao.blog.51cto.com，谢谢合作
#source http://code.google.com/p/auto-task-pe/

green='\e[0;32m' 
red='\e[0;31m' 
blue='\e[0;36m' 
blue1='\e[5;31m' 
NC='\e[0m' 
path_soft=$(pwd)

function base {
#   rpm -e lrzsz&& yum -y install lrzsz*
#   [ "$?" != "0" ] && echo "yum is badly,please check" && exit 1
   for i in  $(rpm -q gcc gcc-c++ autoconf libjpeg libjpeg-devel libpng libpng-devel freetype freetype-devel libxml2 libxml2-devel zlib zlib-devel glibc glibc-devel glib2 glib2-devel bzip2 bzip2-devel ncurses ncurses-devel curl curl-devel e2fsprogs e2fsprogs-devel krb5-devel libidn libidn-devel openssl openssl-devel bison bison-devel readline readline-devel libmcrypt libmcrypt-devel net-snmp-devel gcc  gcc-c++ apr apr-util postgresql-libs  openssl openssl-devel autoconf automake fiex* libxml* ncurses*  libtool* libxslt libxslt-devel curl* bzip2*  gd gd-devel freetype freetype-devel libpng*|grep 'not installed' | awk '{print $2}')  
   do 
	yum -y  install $i; 
   done 
}


function lamp {
yum -y install httpd mysql-server mysql php* net-snmp*  rrdtool*
sed -i "s/;date.timezone =/date.timezone = Asia\/Chongqing/g" /etc/php.ini
#start lamp services
for  name  in  httpd  mysqld snmpd
   do
	service  ${name}  restart
	chkconfig --add ${name}
	chkconfig --level 345 ${name} on
   done
for name1 in nfslock rpcbind
   do
        service  ${name1}  stop
        chkconfig --del ${name1}
   done
   echo  -e "<?php\nphpinfo();\n?>">/var/www/html/test.php
}

#add php_type
#echo "AddType application/x-httpd-php .php" >>/etc/httpd/conf/httpd.conf
#sed -i "s/AddType\ application\/x-gzip\ \.gz\ \.tgz/AddType\ application\/x-gzip\ \.gz\ \.tgz\ AddType\ application\/x-httpd-php\ .php/g" /etc/httpd/conf/httpd.conf
#sed -i "s/DirectoryIndex\ index.html\ index.html.var/DirectoryIndex\ index.php\ index.html\ index.html.var/g"  /etc/httpd/conf/httpd.conf

#install cacti
function install_cacti {
cd  ${path_soft}
[ ! -e cacti*.tar.gz ]; stats=$? 
[ "$stats" == 0 ] && echo -e "${red} there is not cacti*.tar.gz file${NC}" && wget --no-check-certificate http://www.cacti.net/downloads/cacti-0.8.8a.tar.gz
tar zxvf cacti*.tar.gz
cp -rf cacti-0.8.8a  /var/www/html/cacti
restorecon -R -v '/var/www/html/cacti'
chown  apache.apache  -R  /var/www/html/cacti/
sed -i "s/\$database_username\ =\ \"cactiuser\"/\$database_username\ =\ \"cacti\"/g" /var/www/html/cacti/include/config.php  
sed -i "s/\$database_password\ =\ \"cactiuser\"/\$database_password\ =\ \"cacti123\"/g" /var/www/html/cacti/include/config.php

#database password setting
mysqladmin  -uroot password 'itnihao'
mysqladmin  -uroot  -pitnihao  flush-privileges
mysqladmin  -uroot  -pitnihao  create cacti
mysql -uroot  -pitnihao  cacti </var/www/html/cacti/cacti.sql
mysql -uroot  -pitnihao  -e "grant all on cacti.* to cacti@localhost identified by 'cacti123'"
mysql -uroot  -pitnihao  -e "FLUSH PRIVILEGES"

#add crontab
chmod 777 -R  /var/www/html/cacti/rra
chmod 777 -R  /var/www/html/cacti/log
echo "*/5 * * * * /usr/bin/php /var/www/html/cacti/poller.php > /dev/null 2&1" >/tmp/cron.cacti
crontab -l|sort|uniq >>  /tmp/cron.cacti
crontab -uroot /tmp/cron.cacti && rm -rf /tmp/cron.cacti
#setsebool -P httpd_unified=1
#chcon -t httpd_sys_content_t /usr/local/rrdtool -R
echo -e "${green}++++++++++++++++++++++++cacti installed OK,path is http://ip/cacti++++++++++++++++++++${NC}"

}

function plugin {
cd     ${path_soft}/plugin
[ ! -e cacti-spine-0.8.8a.tar.gz ]; stats=$?
[ "$stats" == 0 ] && echo -e "${red} there is not cacti-spine*.tar.gz file${NC}" && wget --no-check-certificate  http://www.cacti.net/downloads/spine/cacti-spine-0.8.8a.tar.gz
tar zxvf  cacti-spine-0.8.8a.tar.gz
cd cacti-spine-0.8.8a
./configure
make && make install
cd ../
mv /usr/local/spine/etc/spine.conf.dist /usr/local/spine/etc/spine.conf
#wget http://docs.cacti.net/_media/plugin:docs-v0.4-1.tgz
#wget http://docs.cacti.net/_media/plugin:boost-v5.0-1.tgz
#wget http://docs.cacti.net/_media/plugin:discovery-v1.5-1.tgz
#wget http://docs.cacti.net/_media/plugin:monitor-v1.2-1.tgz
#wget http://docs.cacti.net/_media/plugin:monitor-v1.3-1.tgz
#wget http://docs.cacti.net/_media/plugin:mobile-latest.tgz
#wget http://docs.cacti.net/_media/plugin:settings-v0.7-1.tgz
#wget http://docs.cacti.net/_media/plugin:syslog-v1.22-2.tgz
#wget http://docs.cacti.net/_media/plugin:thold-v0.4.9-3.tgz
#wget http://docs.cacti.net/_media/plugin:clog-v1.7-1.tgz
#wget http://docs.cacti.net/_media/plugin:ntop-v0.2-1.tgz
#wget http://docs.cacti.net/_media/plugin:domains-v0.1-1.tgz
#wget http://docs.cacti.net/_media/userplugin:manage-0.6.2.zip
#wget http://wotsit.thingy.com/haj/cacti/quicktree-0.2.zip
#wget http://www.network-weathermap.com/files/php-weathermap-0.97a.zip
#wget http://docs.cacti.net/_media/plugin:timeshift-latest.zip 
#wget http://docs.cacti.net/_media/plugin:loginmod-latest.tgz
#wget http://docs.cacti.net/_media/plugin:realtime-v0.5-2.tgz
 
  for name in `ls|sed -e "s/plugin://g" -e "s/.tgz//g"`
  do
      mv plugin:${name}.tgz ${name}.tar.gz
  done

  for name1 in boost discovery docs domains loginmod-latest manage monitor quicktree realtime settings syslog thold timeshift weathermap
  do
     tar zxvf ${name1}*.tar.gz
     mv ${name1} /var/www/html/cacti/plugins/
  done
  chown apache.apache -R /var/www/html/cacti/plugins
}



function config_apache {
cat >> /etc/httpd/conf/httpd.conf << EOF
Alias /cacti "/var/www/html/cacti"
<Directory "/var/www/html/cacti">
   Options -Indexes MultiViews -FollowSymLinks
   DirectoryIndex index.php
   AllowOverride None
   Order allow,deny
   Allow from all
</Directory>
<Directory /var/www/html/cacti/plugin/weathermap>
   <Files editor.php>
            Order Deny,Allow
            Deny from all
            Allow from 127.0.0.1
        </Files>
</Directory> 
EOF
}


function syslog {
#syslog_mysql
yum install -y rsyslog rsyslog-mysql 
cat >> /etc/rsyslog.conf << EOF
$ModLoad imudp.so
$UDPServerRun 514
$ModLoad ommysql
$template cacti_syslog,"INSERT INTO syslog_incoming(facility, priority, date, time, host, message) values (%syslogfacility%, 
%syslogpriority%,  '%timereported:::date-mysql%', '%timereported:::date-mysql%', '%HOSTNAME%', '%msg%')", SQL
*.*             >localhost,syslog,cacti_log,cacti_log_pass;cacti_syslog
EOF
sed -i "s/SYSLOGD_OPTIONS=\"-c 4\"/SYSLOGD_OPTIONS=\"-c 4 -r -m 1\"/g"  /etc/sysconfig/rsyslog 
chkconfig rsyslog on
service rsyslog restart

#syslog_database 
mysqladmin  -uroot  -pitnihao  create syslog
mysql -uroot  -pitnihao  syslog </var/www/html/cacti/plugins/syslog/syslog.sql
mysql -uroot  -pitnihao  -e "grant all on syslog.* to cacti_log@localhost identified by 'cacti_log_pass'"
mysql -uroot  -pitnihao  -e "FLUSH PRIVILEGES"

#cacti_syslog
sed -i "s/use_cacti_db = true;/use_cacti_db = false;/g" /var/www/html/cacti/plugins/syslog/config.php
sed -i "s/syslogdb_username = 'cactiuser'/syslogdb_username = 'cacti_log'/g" /var/www/html/cacti/plugins/syslog/config.php
sed -i "s/syslogdb_password = 'cactiuser'/syslogdb_password = 'cacti_log_pass'/g" /var/www/html/cacti/plugins/syslog/config.php
#client_syslog or rsyslog
#echo "*.* @192.168.16.200"  >> /etc/syslog.conf
#echo "*.* @192.168.16.200"  >> /etc/rsyslog.conf
}

function syslog_ng {
service rsyslog stop
chkconfig --del rsyslog
service syslog stop
chkconfig --del syslog
cd ${path_soft}/syslog
#rhel5.X
#wget http://dl.fedoraproject.org/pub/epel/5/x86_64/eventlog-0.2.12-1.el5.i386.rpm
#wget http://dl.fedoraproject.org/pub/epel/5/x86_64/eventlog-devel-0.2.12-1.el5.x86_64.rpm
#wget http://dl.fedoraproject.org/pub/epel/5/x86_64/eventlog-devel-0.2.12-1.el5.i386.rpm
#wget http://dl.fedoraproject.org/pub/epel/5/x86_64/eventlog-static-0.2.12-1.el5.x86_64.rpm

#wget http://dl.fedoraproject.org/pub/epel/5/x86_64/libnet-1.1.5-1.el5.x86_64.rpm
#wget http://dl.fedoraproject.org/pub/epel/5/x86_64/libnet-1.1.5-1.el5.i386.rpm
#wget http://dl.fedoraproject.org/pub/epel/5/x86_64/libnet-devel-1.1.5-1.el5.i386.rpm
#wget http://dl.fedoraproject.org/pub/epel/5/x86_64/libnet-devel-1.1.5-1.el5.x86_64.rpm

#rhel6.X
#wget http://dl.fedoraproject.org/pub/epel/6/x86_64/eventlog-0.2.12-1.el6.i686.rpm
#wget http://dl.fedoraproject.org/pub/epel/6/x86_64/eventlog-0.2.12-1.el6.x86_64.rpm
#wget http://dl.fedoraproject.org/pub/epel/6/x86_64/eventlog-devel-0.2.12-1.el6.i686.rpm
#wget http://dl.fedoraproject.org/pub/epel/6/x86_64/eventlog-devel-0.2.12-1.el6.x86_64.rpm

#wget http://dl.fedoraproject.org/pub/epel/6/x86_64/libnet-1.1.5-1.el6.i686.rpm
#wget http://dl.fedoraproject.org/pub/epel/6/x86_64/libnet-1.1.5-1.el6.x86_64.rpm
#wget http://dl.fedoraproject.org/pub/epel/6/x86_64/libnet-devel-1.1.5-1.el6.i686.rpm
#wget http://dl.fedoraproject.org/pub/epel/6/x86_64/libnet-devel-1.1.5-1.el6.x86_64.rpm

#wget ftp://fr2.rpmfind.net/linux/epel/6/x86_64/syslog-ng-3.2.5-3.el6.x86_64.rpm
#wget ftp://rpmfind.net/linux/epel/6/i386/syslog-ng-3.2.5-3.el6.i686.rpm
#wget ftp://rpmfind.net/linux/epel/5/x86_64/syslog-ng-2.1.4-9.el5.x86_64.rpm
#wget ftp://rpmfind.net/linux/epel/5/i386/syslog-ng-2.1.4-9.el5.i386.rpm

#############################download####################################
#wget wget http://dl.fedoraproject.org/pub/epel/6/x86_64/libnet-1.1.5-1.el6.x86_64.rpm
#wget http://dl.fedoraproject.org/pub/epel/6/x86_64/eventlog-0.2.12-1.el6.x86_64.rpm
#wget ftp://fr2.rpmfind.net/linux/epel/6/x86_64/syslog-ng-3.2.5-3.el6.x86_64.rpm
#wget http://dl.fedoraproject.org/pub/epel/6/x86_64/syslog-ng-libdbi-3.2.5-3.el6.x86_64.rpm
########################################################################
rpm -ivh libnet-1.1.5-1.el6.x86_64.rpm
rpm -ivh eventlog-0.2.12-1.el6.x86_64.rpm 
rpm -ivh syslog-ng-3.2.5-3.el6.x86_64.rpm
rpm -ivh libdbi-0.8.3-3.1.el6.x86_64.rpm
rpm -ivh syslog-ng-libdbi-3.2.5-3.el6.x86_64.rpm

cat >> /etc/syslog-ng/syslog-ng.conf  << EOF
source s_rsc {
               unix-stream("/dev/log");
               udp(ip("192.168.16.200") port(514));
};

#destination r_mesg  { file("/var/log/warn");};

destination d_mysql {
                    program("mysql -ucacti_log -pcacti_log_pass syslog < /var/log/mysql.pipe");
                    pipe("/var/log/mysql.pipe"
                    template("INSERT INTO syslog_incoming (host, facility, priority, status, date, time, seq, message) VALUES( '\$FULLHOST', '\$FACILITY', '\$PRIORITY', '\$STATUS', '\$YEAR-\$MONTH-\$DAY', '\$HOUR:\$MIN:\$SEC','\$SEQ', '\$MESSAGE' );\n")
                    template-escape(yes));
};


log { source(s_rsc); destination(d_mysql); };
log { source(s_sys); destination(d_mysql); };
EOF
}

function client_config {
#client syslog-ng,you should install syslog-ng 
cat >> /etc/syslog-ng/syslog-ng.conf  << EOF
destination d_udp {udp("192.168.16.200" port(514));};
log { source(s_sys); destination(d_udp);};
EOF

#client_syslog or rsyslog
#rhel5.X use syslog
echo "*.* @192.168.16.200"  >> /etc/syslog.conf
#rhel6.X use rsyslog
echo "*.* @192.168.16.200"  >> /etc/rsyslog.conf



#clietn snmpd configuration
sed -i s"/^/#/g" /etc/snmp/snmpd.conf
cat >> /etc/snmp/snmpd.conf << EOF
com2sec mynetwork 192.168.16.200 public
com2sec mynetwork 127.0.0.1 public 
group MyROGroup v2c mynetwork
access MyROGroup "" any noauth prefix all none none  
view all included .1 80
EOF
}


function main {
base
lamp
install_cacti
plugin
config_apache
syslog
#syslog_ng
#client_config
}

main
