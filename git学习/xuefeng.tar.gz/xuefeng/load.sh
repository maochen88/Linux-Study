#!/bin/bash
#

URI=$(grep -o 'href="/wiki/001373951630.*' a.html |cut -d'"' -f2|sort|uniq)
HEAD="http://www.liaoxuefeng.com"

for i in ${URI}
do
	wget ${HEAD}${i}
done
